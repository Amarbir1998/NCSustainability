﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NC_Sustainability.Data.NCMigrations
{
    public partial class email : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
