﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NC_Sustainability.ViewModels
{
    public class OptionsVM
    {
        public int ID { get; set; }
        public string DisplayText { get; set; }
    }
}
